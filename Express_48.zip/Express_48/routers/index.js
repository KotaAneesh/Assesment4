const { Router }=require("express");
const employee=require("./employee.route");

const router=new Router();
router.use("/employees",employee);
module.exports=router;