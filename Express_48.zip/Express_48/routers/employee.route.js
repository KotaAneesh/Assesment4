const { Router }=require("express");
const router=new Router();

const getEmp=require("../service/employee.getemployees");
const getEmpByID=require("../service/employee.getempbyID");
router.get("/getemp",getEmp.getEmp);
router.get("/getemp:id",getEmpByID.getEmpByID);
module.exports=router;