var employees=[        {
    "EmployeeID": "0",
    "EmployeeName": "Aneesh",
    "Role": "Frontend Developer",
    
},
{
    "EmployeeID": "1",
    "EmployeeName": "Madhukar",
    "Role": "Backend Developer",
    
},
{
    "EmployeeID": "2",
    "EmployeeName": "Ganesh",
    "Role": "Designer",
    
}
];
module.exports=employees;